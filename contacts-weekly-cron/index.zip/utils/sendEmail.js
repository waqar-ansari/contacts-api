const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "smtp", // Use your SMTP service
  host: "smtp.titan.email", // SMTP server address
  port: 465, // Port for secure connection
  secure: true, // Use SSL/TLS
  auth: {
    user: "noreply@contacts.management",
    pass: "bZ}JTus_PQ{qWvA", // App Password, not normal password
    // user: "makvanayash12@gmail.com",
    // pass: "fybb lnri tmrq otmg", // App Password, not normal password
  },
  // optional TLS options:
  tls: {
    // do not fail on invalid certs in dev (remove in prod)
    rejectUnauthorized: false,
  },
});

function sendMail(mailOptions) {
  return transporter.sendMail(mailOptions);
}

module.exports = {

  transporter,
  sendMail
};