const whoScannedMe = async(req,res)=>{

}

module.exports={whoScannedMe}