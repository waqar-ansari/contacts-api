const iScannedWho = async(req,res)=>{

    try {
        
    } catch {
        
    }
}

module.exports={iScannedWho}